<?php
/**
 * Pages du site (FAQ, À propos, Contact, Risques, textes légaux, Espace membre).
 *
 * Créées UNE SEULE FOIS, si elles n'existent pas déjà. Une page modifiée dans le tableau de bord
 * n'est jamais écrasée, et une page supprimée volontairement n'est pas recréée.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Arvator_Pages {

	private const OPT_CREATED = 'arvator_pages_created';
	private const OPT_REV     = 'arvator_pages_rev';
	private const OPT_REVIEW  = 'arvator_pages_review';

	/**
	 * Création des pages manquantes et mise à jour des textes améliorés (appelée à l'installation et à chaque
	 * mise à jour du plugin).
	 *
	 * - Page absente et jamais créée : elle est créée.
	 * - Page supprimée volontairement : elle n'est pas recréée.
	 * - Texte amélioré dans une nouvelle version : remplacé SEULEMENT si la page n'a jamais été modifiée dans
	 *   l'éditeur ; sinon la page est conservée telle quelle et signalée dans l'administration.
	 */
	public static function create_missing(): void {
		$defs    = require ARVATOR_CORE_DIR . 'includes/content/pages.php';
		$done    = (array) get_option( self::OPT_CREATED, array() );
		$revs    = (array) get_option( self::OPT_REV, array() );
		$review  = (array) get_option( self::OPT_REVIEW, array() );
		$authors = get_users(
			array(
				'role'   => 'administrator',
				'number' => 1,
				'fields' => 'ID',
			)
		);
		$author  = $authors ? (int) $authors[0] : 0;

		foreach ( $defs as $slug => $def ) {
			$rev  = (int) ( $def['rev'] ?? 1 );
			$page = get_page_by_path( $slug, OBJECT, 'page' );

			if ( in_array( $slug, $done, true ) ) {
				// Page déjà créée auparavant : mise à jour éventuelle du texte.
				if ( $page instanceof WP_Post && (int) ( $revs[ $slug ] ?? 1 ) < $rev ) {
					if ( self::is_untouched( $page ) ) {
						self::replace_content( $page, self::to_blocks( $def['text'] ) );
						$revs[ $slug ] = $rev;
						$review        = array_values( array_diff( $review, array( $slug ) ) );
					} elseif ( ! in_array( $slug, $review, true ) ) {
						$review[] = $slug;
					}
				}
				continue;
			}

			if ( null === $page ) {
				wp_insert_post(
					array(
						'post_type'      => 'page',
						'post_status'    => 'publish',
						'post_name'      => $slug,
						'post_title'     => $def['title'],
						'post_content'   => self::to_blocks( $def['text'] ),
						'post_author'    => $author,
						'comment_status' => 'closed',
						'ping_status'    => 'closed',
					)
				);
				$revs[ $slug ] = $rev;
			}
			$done[] = $slug;
		}

		self::set_front_page();
		update_option( self::OPT_CREATED, array_values( array_unique( $done ) ), false );
		update_option( self::OPT_REV, $revs, false );
		update_option( self::OPT_REVIEW, $review, false );
		self::apply_fixes();
	}

	/**
	 * Corrections ciblées sur les pages déjà en ligne, MÊME si Hamid les a modifiées dans l'éditeur
	 * (demande de Hamid du 28/10/2026) : seules les phrases fautives sont remplacées, le reste de la page est conservé.
	 * Chaque correction ne fait rien si la page est déjà juste : on peut la relancer sans risque.
	 */
	private static function apply_fixes(): void {
		$sp = '(?:\s|&nbsp;|&#160;|\x{00A0}|\x{202F})';

		foreach ( array( 'risques', 'faq', 'mentions-legales', 'cgv', 'confidentialite', 'contact', 'a-propos', 'conditions-parrainage', 'parrainage', 'essai-gratuit' ) as $slug ) {
			$page = get_page_by_path( $slug, OBJECT, 'page' );
			if ( ! $page instanceof WP_Post ) {
				continue;
			}
			$new = (string) $page->post_content;
			$new = (string) preg_replace( '/(au' . $sp . '+moins' . $sp . '+)2' . $sp . '?000(' . $sp . '?€)/u', '${1}5 000$2', $new );
			foreach ( self::RESULT_FIXES as $fix ) {
				$new = str_replace( array( self::inline( $fix[0] ), $fix[0] ), array( self::inline( $fix[1] ), $fix[1] ), $new );
			}
			$new = str_replace( array( 'contact@cosmartis.com', 'bot.cosmartis.com' ), array( Arvator_Site::EMAIL, Arvator_Site::DOMAIN ), $new );

			if ( 'confidentialite' === $slug && ! str_contains( $new, 'Assistant de discussion' ) ) {
				$block = self::to_blocks( self::CHAT_PRIVACY );
				$pos   = strpos( $new, "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Cookies</h2>" );
				$new   = false === $pos ? rtrim( $new ) . "\n\n" . $block : substr( $new, 0, $pos ) . $block . substr( $new, $pos );
			}

			if ( $new !== $page->post_content ) {
				self::replace_content( $page, $new );
			}
		}
	}

	/**
	 * Résultats (demande de Hamid du 01/11/2026) : « performances simulées » → « résultats backtestés », capital conseillé 5 000 €,
	 * plus de « trades refusés ». Paires [ancienne phrase, nouvelle phrase], appliquées même sur une page modifiée dans l'éditeur.
	 */
	private const RESULT_FIXES = array(
		array( '- **Transparence :** nous montrons des performances simulées (backtest), toujours accompagnées des baisses de chaque simulation. Nous ne vendons pas de promesse.', '- **Transparence :** nous montrons des résultats backtestés, toujours avec les baisses qui vont avec. Nous ne vendons pas de promesse.' ),
		array( 'Les résultats présentés sont des simulations sur 2024, 2025 et 2026.', 'Les résultats présentés sont des backtests sur 2024, 2025 et 2026.' ),
		array( 'Les résultats affichés sont des performances simulées (backtest 2024-2026) qui ne préjugent pas', 'Les résultats affichés sont des résultats backtestés (2024-2026) qui ne préjugent pas' ),
		array( 'Non, ce sont des simulations (backtest) réalisées sur 2024, 2025 et 2026.', 'Non, ce sont des backtests réalisés sur cTrader de 2024 à 2026, frais du courtier inclus.' ),
		array( '?? Pourquoi conseillez-vous au moins 2 000 € ?', '?? Pourquoi conseillez-vous au moins 5 000 € ?' ),
		array( 'Ce n\'est pas une obligation. Avec un petit capital, la taille minimale de position imposée par le courtier ferait risquer plus que prévu : le robot refuse alors le trade. Il en prend donc moins, et les résultats deviennent plus irréguliers. À partir de 2 000 €, notre backtest (qui inclut les frais d\'un courtier, par exemple IC Markets) ne compte que 20 trades refusés au risque 1 %, et aucun aux risques 2 % et 3 %.', 'Ce n\'est pas une obligation. C\'est le capital de référence de nos backtests : au réglage livré (1 %), plus le capital est petit, plus les baisses sont fortes en pourcentage. Voir les résultats par capital sur la [page d\'accueil](/#resultats).' ),
		array( 'Les résultats présentés sont des performances simulées et ne préjugent pas des résultats futurs. Ce logiciel', 'Les résultats présentés sont des résultats backtestés et ne préjugent pas des résultats futurs. Ce logiciel' ),
		array( '## Les résultats affichés sont des simulations', '## Les résultats affichés sont des backtests' ),
		array( '- Ce sont des performances simulées (backtest), réalisées sur 2024, 2025 et 2026. Elles ne sont pas des résultats réels.', '- Ce sont des résultats backtestés sur cTrader, du 1er janvier 2024 au 31 octobre 2026, frais du courtier inclus. Ce ne sont pas des résultats réels.' ),
		array( 'Chaque simulation affichée montre la pire baisse et le solde le plus bas. Plus le niveau de risque est élevé (1 %, 2 % ou 3 % par trade), plus les gains simulés comme les baisses', 'Chaque résultat affiché montre la pire baisse. Plus le niveau de risque est élevé (1 %, 2 % ou 3 % par trade), plus les gains comme les baisses' ),
		array( 'Avec un petit capital, beaucoup de trades sont refusés (taille minimale de position imposée par le courtier) : le robot en prend moins et les résultats sont plus irréguliers. Nous conseillons au moins 2 000 €, sans que ce soit une garantie de résultat.', 'Avec un petit capital, les baisses sont plus fortes en pourcentage. Nous conseillons au moins 5 000 €, sans que ce soit une garantie de résultat.' ),
		array( 'Les résultats présentés sont des performances simulées. Voir la page', 'Les résultats présentés sont des résultats backtestés. Voir la page' ),
		array( 'Les résultats présentés sont des performances simulées et ne préjugent pas des résultats futurs. Le client', 'Les résultats présentés sont des résultats backtestés et ne préjugent pas des résultats futurs. Le client' ),
		array( 'les performances présentées sur ce site sont **simulées** (backtest 2024-2026)', 'les résultats présentés sur ce site sont des **résultats backtestés** (2024-2026)' ),
		array( 'les performances présentées sont simulées et le trading', 'les résultats présentés sont des résultats backtestés et le trading' ),
		array( 'Les résultats présentés sur le site sont des performances simulées : le trading', 'Les résultats présentés sur le site sont des résultats backtestés : le trading' ),
		array( 'des performances simulées', 'des résultats backtestés' ),
		array( 'performances simulées', 'résultats backtestés' ),
	);

	/** Paragraphe « Assistant de discussion » de la politique de confidentialité (aussi dans content/pages.php). */
	public const CHAT_PRIVACY = "## Assistant de discussion\nLes messages que vous écrivez à l'assistant de discussion (la bulle en bas à droite du site) sont transmis à un fournisseur d'intelligence artificielle pour générer la réponse. Ils ne sont pas conservés. N'y écrivez pas de données personnelles (mot de passe, numéro de carte, coordonnées bancaires).";

	/**
	 * Page « Accueil » choisie comme page d'accueil du site (Réglages > Lecture), une seule fois et seulement si aucune
	 * autre page d'accueil n'est déjà choisie : un choix fait ensuite dans le tableau de bord est respecté.
	 */
	private static function set_front_page(): void {
		if ( get_option( 'arvator_front_set' ) ) {
			return;
		}
		$home = get_page_by_path( 'accueil', OBJECT, 'page' );
		if ( ! $home instanceof WP_Post || 'publish' !== $home->post_status ) {
			return;
		}
		$current = (int) get_option( 'page_on_front', 0 );
		if ( 'page' !== get_option( 'show_on_front' ) || 0 === $current || ! get_post( $current ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', (int) $home->ID );
		}
		update_option( 'arvator_front_set', 1, false );
	}

	/** Une page « jamais touchée » a la même date de création et de dernière modification. */
	private static function is_untouched( WP_Post $page ): bool {
		return $page->post_modified_gmt === $page->post_date_gmt;
	}

	/** Remplace le texte en conservant les dates d'origine (la page reste « jamais touchée »). */
	private static function replace_content( WP_Post $page, string $content ): void {
		global $wpdb;
		$wpdb->update( $wpdb->posts, array( 'post_content' => $content ), array( 'ID' => $page->ID ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		clean_post_cache( $page->ID );
	}

	/** Pages dont le texte a été amélioré mais que Hamid a modifiées (donc non remplacées). */
	public static function pages_to_review(): array {
		$out = array();
		foreach ( (array) get_option( self::OPT_REVIEW, array() ) as $slug ) {
			$page = get_page_by_path( (string) $slug, OBJECT, 'page' );
			if ( $page instanceof WP_Post ) {
				$out[ (string) $slug ] = $page;
			}
		}
		return $out;
	}

	/** Efface la liste « à relire ». */
	public static function dismiss_review(): void {
		update_option( self::OPT_REVIEW, array(), false );
	}

	/**
	 * Convertit un texte simple en blocs WordPress (modifiables ensuite dans l'éditeur).
	 *
	 * Syntaxe : « ## Titre », « ### Sous-titre », « - élément », « ?? Question » suivie de sa réponse,
	 * « [provisoire] », « [arvator_contact] », **gras**, [texte](/page/).
	 */
	public static function to_blocks( string $text ): string {
		$text  = strtr(
			$text,
			array(
				'{{email}}'   => Arvator_Site::EMAIL,
				'{{domain}}'  => Arvator_Site::DOMAIN,
				'{{adresse}}' => Arvator_Site::POSTAL,
			)
		);
		$lines = preg_split( '/\R/', trim( $text ) );
		$lines = is_array( $lines ) ? $lines : array();
		$out   = '';
		$i     = 0;
		$n     = count( $lines );

		while ( $i < $n ) {
			$line = rtrim( $lines[ $i ] );

			if ( '' === $line ) {
				++$i;
				continue;
			}
			if ( str_starts_with( $line, '### ' ) ) {
				$out .= "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">" . self::inline( substr( $line, 4 ) ) . "</h3>\n<!-- /wp:heading -->\n\n";
				++$i;
				continue;
			}
			if ( str_starts_with( $line, '## ' ) ) {
				$out .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . self::inline( substr( $line, 3 ) ) . "</h2>\n<!-- /wp:heading -->\n\n";
				++$i;
				continue;
			}
			if ( '[provisoire]' === $line ) {
				$out .= "<!-- wp:paragraph {\"className\":\"notice-provisional\"} -->\n<p class=\"notice-provisional\"><strong>Version provisoire.</strong> Ce texte doit être validé par un avocat avant l’ouverture du site au public.</p>\n<!-- /wp:paragraph -->\n\n";
				++$i;
				continue;
			}
			if ( 1 === preg_match( '/^\[(arvator_[a-z_]+)\]$/', $line, $m ) ) {
				$out .= "<!-- wp:shortcode -->\n[" . $m[1] . "]\n<!-- /wp:shortcode -->\n\n";
				++$i;
				continue;
			}
			if ( str_starts_with( $line, '- ' ) ) {
				$items = array();
				while ( $i < $n && str_starts_with( rtrim( $lines[ $i ] ), '- ' ) ) {
					$items[] = substr( rtrim( $lines[ $i ] ), 2 );
					++$i;
				}
				$out .= self::list_block( $items );
				continue;
			}
			if ( str_starts_with( $line, '?? ' ) ) {
				$question = substr( $line, 3 );
				++$i;
				$answer = array();
				while ( $i < $n && '' !== rtrim( $lines[ $i ] ) ) {
					$answer[] = rtrim( $lines[ $i ] );
					++$i;
				}
				$out .= "<!-- wp:details -->\n<details class=\"wp-block-details\"><summary>" . self::inline( $question ) . "</summary>\n"
					. rtrim( self::to_blocks( implode( "\n", $answer ) ) )
					. "</details>\n<!-- /wp:details -->\n\n";
				continue;
			}

			$para = array();
			while ( $i < $n && '' !== rtrim( $lines[ $i ] ) && ! preg_match( '/^(## |### |- |\?\? |\[provisoire\]|\[arvator_)/', rtrim( $lines[ $i ] ) ) ) {
				$para[] = trim( $lines[ $i ] );
				++$i;
			}
			$out .= "<!-- wp:paragraph -->\n<p>" . self::inline( implode( ' ', $para ) ) . "</p>\n<!-- /wp:paragraph -->\n\n";
		}

		return $out;
	}

	/** @param string[] $items */
	private static function list_block( array $items ): string {
		$li = '';
		foreach ( $items as $item ) {
			$li .= "<!-- wp:list-item -->\n<li>" . self::inline( $item ) . "</li>\n<!-- /wp:list-item -->";
		}
		return "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . $li . "</ul>\n<!-- /wp:list -->\n\n";
	}

	/** Texte → HTML sûr : on échappe tout, puis on ne réactive que le gras et les liens internes. */
	private static function inline( string $s ): string {
		$s = esc_html( $s );
		$s = (string) preg_replace( '/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $s );
		$s = (string) preg_replace( '/\[([^\]]+)\]\((\/[a-z0-9\-\/#]*)\)/i', '<a href="$2">$1</a>', $s );
		return $s;
	}
}
